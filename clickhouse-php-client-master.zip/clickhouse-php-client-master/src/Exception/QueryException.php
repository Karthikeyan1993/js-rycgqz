<?php
namespace ClickHouse\Exception;


class QueryException extends \LogicException
{

}