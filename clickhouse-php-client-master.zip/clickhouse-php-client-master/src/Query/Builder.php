<?php

namespace ClickHouse\Query;

class Builder
{

}