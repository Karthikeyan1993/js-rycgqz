<?php

namespace ClickHouse\Query;

interface QueryInterface
{


    public function table();
    public function select();



}