<?php
return [
    'host' => 'tabix.dev7', // you hot name
    'port' => '8123',
    'username' => 'default',
    'password' => ''
];