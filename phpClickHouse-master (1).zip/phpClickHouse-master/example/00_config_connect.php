<?php
return [
    'host' => '127.0.0.1', // you hot name
    'port' => '8123',
    'username' => 'default',
    'password' => ''
];